#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <time.h>
/*--------ETAPE 0 DECLARATION DU BIBLIOTHEQUE SDL ---------------*/
#include <SDL/SDL_ttf.h>    // pour manipuler des texte 
#include <SDL/SDL_image.h>  // pour manipuler des image 
#include <SDL/SDL_mixer.h>  // pour manipuler des audio 
/*-------------------------------------------------------------------*/ 
#include <math.h>

#include "lot1.h"  

/*--------------------------manipulation de l'image ----------------------------------*/
       /*-----------------------initialisation -----------------------*/
void initPerso(personne *p  )  //  initialisation de la perosnnage principale
{
p->url="main.png" ; 
p->sprite=IMG_Load(p->url) ; 
if (p->sprite == NULL) 
{
printf("unable to load background image %s \n",SDL_GetError()) ;
 return ;  
}
p->pos_Screen.x=0 ; 
p->pos_Screen.y=350; 
p->pos_Sprite.x=0 ; 
p->pos_Sprite.y=1092; 

p->pos_Sprite.w=260; 
p->pos_Sprite.h=273 ;


if (p->direction ==1  ) //i9adam 
{p->pos_Sprite.x=0 ; 
p->pos_Sprite.y=1092; 

p->pos_Sprite.w=260; 
p->pos_Sprite.h=273 ; }

else if (p->direction == 0  )  // iwa5ar 
{p->pos_Sprite.x=0 ; 
p->pos_Sprite.y=1365; 


p->pos_Sprite.w=260; 
p->pos_Sprite.h=273 ; }

/*else if (p->d ==-1  )  // attack imin 
{p->pos_Sprite.x=0 ; 
p->pos_Sprite.y=0; 


p->pos_Sprite.w=260 ; 
p->pos_Sprite.h=273 ;}*/

else 
{p->pos_Screen.x=0 ; 
p->pos_Screen.y=350; 
p->pos_Sprite.x=0 ; 
p->pos_Sprite.y=1092; 

p->pos_Sprite.w=260; 
p->pos_Sprite.h=273 ;}

p->vitesse=5;  // initialisation du vitessse a une valeur   
p->acceleration=0;   // acceleration constante 0 
 
p->up=0 ; // initialisation du champ  saut a 0 
}

void movePerso (personne *p , Uint32 dt)   
{
double dx ; 

/*-------------------------------------------------*/
if (p->acceleration == 0 ) 
{
  if (p->direction==1 )  
     {p->vitesse=0;// ha8oma il spritesheet il tsawer kifech yo8hrou
       if (p->pos_Sprite.x <=520 ) 
         {p->pos_Sprite.x=p->pos_Sprite.x+244 ; }
      else 
          { p->pos_Sprite.x=244 ; 
            p->pos_Sprite.y=1092; 
          }
         // ha8ouma i9adem bil position 
       if ( p->pos_Screen.x<=1000 )  
                  {  p->pos_Screen.x=p->pos_Screen.x+5 ;      
                     p->pos_Screen.y=p->pos_Screen.y ;
                  } 
     
 
      
     } 
 else if  (p->direction==0 )  //bich yerja3  
     { 
        // ha8ouma ili i7arkou il sprite sheet ili yirja3 fiha il personnage 
      if (p->pos_Sprite.x <=520)
         {p->pos_Sprite.x=p->pos_Sprite.x+244; }
      else 
          { p->pos_Sprite.x=260; 
            p->pos_Sprite.y=1365; 
          } 
       // ha8ouma iwa5ar bil position 
         if ( p->pos_Screen.x>0)  
                   p->pos_Screen.x=p->pos_Screen.x-5; 
    }
  
else if  (p->direction== 2  ) // wa9if 
{p->pos_Sprite.x=0 ; 
 p->pos_Sprite.y=1092;
if (p->d == -1 ) 
{if (p->pos_Sprite.x ==260 ) 
         {p->pos_Sprite.x=p->pos_Sprite.x+260 ; }
      else 
          { p->pos_Sprite.x=0 ; 
            p->pos_Sprite.y=0; 
          } 
}}
else if  (p->direction== 3  )  // wa9if 
{p->pos_Sprite.x=0; 
 p->pos_Sprite.y=1365;
if (p->d == -1 ) 
{if (p->pos_Sprite.x ==260 ) 
         {p->pos_Sprite.x=p->pos_Sprite.x+260 ; }
      else 
          { p->pos_Sprite.x=0 ; 
            p->pos_Sprite.y=273; 
          } 
}}
else {return ; }

}

else 
{ if (p->vitesse <5 )
   { dx = 0.5 * p->acceleration * dt * dt + p->vitesse * dt;
     if (p->direction==1 )  
     {// ha8oma il spritesheet il tsawer kifech yo8hrou
      if (p->pos_Sprite.x <=520  ) 
         {p->pos_Sprite.x=p->pos_Sprite.x+260 ; }
      else 
          { p->pos_Sprite.x=260 ; 
            p->pos_Sprite.y=1092; 
          }
         // ha8ouma i9adem bil position 
       if ( p->pos_Screen.x<200) 
                  {  p->pos_Screen.x+=dx;      
                     p->pos_Screen.y=p->pos_Screen.y ;
                  }   
      
     } 
 else if  (p->direction==0 )  //bich yerja3  
     {
        // ha8ouma ili i7arkou il sprite sheet ili yirja3 fiha il personnage 
      if (p->pos_Sprite.x <=520)
         {p->pos_Sprite.x=p->pos_Sprite.x+260 ; }
      else 
          { p->pos_Sprite.x=260; 
            p->pos_Sprite.y=1365; 
          } 
       // ha8ouma iwa5ar bil position 
         if ( p->pos_Screen.x>0) 
                   p->pos_Screen.x-=dx; 
    }

else if  (p->direction== 2  ) // wa9if 
{p->pos_Sprite.x=0 ; 
 p->pos_Sprite.y=1092;}
else if  (p->direction== 3  )  // wa9if 
{p->pos_Sprite.x=0; 
 p->pos_Sprite.y=1365;}
else {return ; }

 p->vitesse = p->vitesse+ p->acceleration * dt; // mettre a jour la vitesse en fonction de l acceleration
   
 if (p->vitesse < 0)
    {
        p->vitesse = 0;
        p->acceleration = 0;
    }

     
   }

}

}












/*------------------------saut personne --------------------------------------*/
void saut( personne *p,int dt, int posinit)  // saut du personnage  ( posinit la position initiale du personnage ) saut normale du personnage 
{     
if (p->up == 1  ) 
{
  if (p->direction==1 || p->direction== 2  )  
    { 
       p->pos_Sprite.x=0 ; 
       p->pos_Sprite.y=548; 

      if (p->pos_Sprite.x <=260 ) 
         {p->pos_Sprite.x=p->pos_Sprite.x+244 ; }
      else 
          { p->pos_Sprite.x=0; 
            p->pos_Sprite.y=1092; 
          }

       //bich  yitla3 il fou9 bil position 
       if ( posinit>400) 
         {p->pos_Screen.x =p->pos_Screen.x ;  
          p->pos_Screen.y=p->pos_Screen.y-5;
          }
 
      
     } 
   else if  (p->direction==0 ||p->direction== 3 )  //bich yerja3  
     { 
        p->pos_Sprite.x=0 ; 
        p->pos_Sprite.y=819; 

       if (p->pos_Sprite.x <=260 ) 
         {p->pos_Sprite.x=p->pos_Sprite.x+244 ; }
       else 
          { p->pos_Sprite.x=0; 
            p->pos_Sprite.y=1365; 
          }

       //bich  yitla3 il fou9 bil position 
       if ( posinit>400) 
           {p->pos_Screen.x =p->pos_Screen.x ;  
            p->pos_Screen.y=posinit-5;}
    }


}

 
}















void drouj ( personne *p, int posx_absolu, int posy_absolu) //  yitla3 il drouj 
{

if (p->up==5 || p->direction==1 || p->direction==3 )  
{ //bich  yitla3 il fou9 bil parabole  
if ( posy_absolu>0) 
    {p->pos_Screen.x =p->pos_Screen.x+50 ;  
     p->pos_Screen.y=posy_absolu-50;}
}
if (p->up==5 || p->direction==2 ||  p->direction==0 )  
{ //bich  yitla3 il fou9 bil parabole  
if ( posy_absolu>0) 
    {p->pos_Screen.x =p->pos_Screen.x-50 ;  
     p->pos_Screen.y=posy_absolu-50;}
}



}

void saut_personnage ( personne *p, Uint32 dt, int posx_absolu, int posy_absolu) // saut parabolique 
{

if (p->up==3 && p->direction==1 ) 
{ //bich  yitla3 il fou9 bil parabole  
if ( posy_absolu>0 ) 
    {p->pos_Screen.x =p->pos_Screen.x+100 ;  // 9otlou yimchi distance x 100 wa yitla3 50
     p->pos_Screen.y=posy_absolu-50;}

}
if (p->up==3 && p->direction==0 && p->pos_Screen.x>0 ) 
{ //bich  yitla3 il fou9 bil parabole  
if ( posy_absolu>0) 
    {p->pos_Screen.x =p->pos_Screen.x-100 ;  // 9otlou yimchi distance x 100 wa yitla3 50
     p->pos_Screen.y=posy_absolu-50;}

}

if (p->up==3 && p->direction==2)  // saut para wa9if imin
{ //bich  yitla3 il fou9 bil parabole  
if ( posy_absolu>0 ) 
    {p->pos_Screen.x =p->pos_Screen.x+100 ;  // 9otlou yimchi distance x 100 wa yitla3 50
     p->pos_Screen.y=posy_absolu-50;}

}
if (p->up==3 && p->direction==3 && p->pos_Screen.x>0 )  // saut paraboli wa9if isar 
{ //bich  yitla3 il fou9 bil parabole  
if ( posy_absolu>0) 
    {p->pos_Screen.x =p->pos_Screen.x-100 ;  // 9otlou yimchi distance x 100 wa yitla3 50
     p->pos_Screen.y=posy_absolu-50;}

}


}




/*----------------------------- animation du personnage */

 void animerPerso (personne* p) 
{  

 
     if (p->pos_Sprite.x <=520 ) 
         {p->pos_Sprite.x=p->pos_Sprite.x+244 ; }
      else 
          { p->pos_Sprite.x=244 ; 
            p->pos_Sprite.y=1092;}

     
}







       /*----------------------affichage -----------------------*/


void afficherPerso(personne p, SDL_Surface * screen)	// affichage du personnage principale  
{
SDL_BlitSurface(p.sprite ,&p.pos_Sprite   , screen , &p.pos_Screen ) ; 

}


    




       /*----------------------liberation  -----------------------*/
void liberer_perso_image(personne p)  
{
SDL_FreeSurface(p.sprite) ;
}





void initialiser_feu(image *imgbtn) 
{
//chargement de l'image
imgbtn->url="feu.png" ; //pour la fonction d'initialisation de l'image du bouton on definit l'url de l'emplacement du fichier de l'image  
imgbtn->img=IMG_Load(imgbtn->url); 
if (imgbtn->img ==NULL)
   {printf("unable to load background image %s ",SDL_GetError());
   return ;}

imgbtn->pos_img_ecran .x=300; 
imgbtn->pos_img_ecran.y=450 ;

imgbtn->pos_img_affiche.x=0 ; 
imgbtn->pos_img_affiche.y=0;

imgbtn->pos_img_affiche.w=100;
imgbtn->pos_img_affiche.h=100 ; 


}

// -------------affichage du image boutton 1 ---------------
void afficher_feu(SDL_Surface *screen , image image )
{ 
SDL_BlitSurface(image.img ,NULL   , screen ,&image.pos_img_ecran ) ; // la fonction SDL_BlitSurface() permet de  coller et afficher l'image du bonton play dans le screen
 
}

/***************** manipulation vie du joueur ********************/
// initialisation image  



void initialiser_coeur(personne *p ,int i ,int *vie) 
{

p->url="coeur.png" ; 
p->sprite=IMG_Load(p->url) ; 
if (p->sprite == NULL) 
{
printf("unable to load background image %s \n",SDL_GetError()) ;
 return ;  
}
p->pos_Screen.x=500 ; 
p->pos_Screen.y=0; 
p->pos_Sprite.x=0 ; 
p->pos_Sprite.y=0; 

p->pos_Sprite.w=200-i; 
p->pos_Sprite.h=42 ;

*vie =*vie-1 ; 

}



/*****************manipulation du score ***************/ 



void initialiser_texte(texte *txte , int k ,int k2 ,int *score )
{ 
 TTF_Init; 

txte -> police = TTF_OpenFont("ubuntu-B.ttf",45) ;
txte -> color_txt.r =0 ; 
txte -> color_txt.g =0 ; 
txte -> color_txt.b = 0; 

txte -> pos_txt.x =200 ; 
txte -> pos_txt.y =0;

char ch1[] = {k,k2, '\0'};

strcpy(txte->ch, ch1);
 txte -> police = TTF_OpenFont("Dark-Graffiti.ttf",70) ;

*score = *score +1 ; 
}




void afficher_texte(SDL_Surface *screen , texte txte) 
{

txte.txt= TTF_RenderText_Blended(txte.police,txte.ch ,txte.color_txt) ; 
SDL_BlitSurface(txte.txt ,NULL , screen ,& txte.pos_txt)  ; 

} 


void liberer_texte(texte txte) 
{
SDL_FreeSurface(txte.txt) ;                                    
}
/*********************************************************/


void initialiser_lost(personne *p ) 
{

p->url="lost.jpg" ; 
p->sprite=IMG_Load(p->url) ; 
if (p->sprite == NULL) 
{
printf("unable to load background image %s \n",SDL_GetError()) ;
 return ;  
}
p->pos_Screen.x=400 ; 
p->pos_Screen.y=200; 
p->pos_Sprite.x=0 ; 
p->pos_Sprite.y=0; 

p->pos_Sprite.w=196; 
p->pos_Sprite.h=293 ;

}

void liberer_imageb(image p) 
{
SDL_FreeSurface(p.img) ;
}

void initialiser_audiobrefj1(Mix_Chunk *music) 
{Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,2,2048) ; 
 music =Mix_LoadWAV("simple.wav") ; 
 Mix_PlayChannel(-1,music,0) ; 

if (music==NULL) printf("%s",SDL_GetError()) ; 
}
void initialiser_audiobrefj2(Mix_Chunk *music) 
{Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,2,2048) ; 
 music =Mix_LoadWAV("song.wav") ; 
 Mix_PlayChannel(-1,music,0) ; 

if (music==NULL) printf("%s",SDL_GetError()) ; 
}
void initialiser_audiobrefj3(Mix_Chunk *music) 
{Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,2,2048) ; 
 music =Mix_LoadWAV("song3.wav") ; 
 Mix_PlayChannel(-1,music,0) ; 

if (music==NULL) printf("%s",SDL_GetError()) ; 
}


   
void liberer_musiquebrefj(Mix_Chunk *music) 
{ Mix_FreeChunk(music) ; }



//////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////   khalil   ///////////////////////////////////////////////////


void initBack(background *b)
{
b->url="enemy.png"; 
b->img=IMG_Load(b->url) ; 
if (b->img == NULL) 
{
printf("unable to load background image %s \n",SDL_GetError()) ;
 return ;  
}
b->pos_img_ecran.x=0; 
b->pos_img_ecran.y=0; 
b->camera_pos.x=0; 
b->camera_pos.y=50; 
b->camera_pos.h=SCREEN_H ; 
b->camera_pos.w=SCREEN_W ;

}


void initanimation(background *b)
{
b->url="fire.png"; 
b->img=IMG_Load(b->url) ; 
if (b->img == NULL) 
{
printf("unable to load background image %s \n",SDL_GetError()) ;
 return ;  
}
b->pos_img_ecran.x=30; 
b->pos_img_ecran.y=30; 
b->camera_pos.x=0; 
b->camera_pos.y=0; 
b->camera_pos.h=SCREEN_H ; 
b->camera_pos.w=SCREEN_W ;

}
void afficherback(SDL_Surface *screen,background b )
{ 
SDL_BlitSurface(b.img ,&b.camera_pos , screen , &b.pos_img_ecran ) ; 
}

void scrolling(background *b, int direction,int pas) {
    switch (direction) {
        case 0:
            b->camera_pos.x += pas;
            break;
        case 1:
            b->camera_pos.x = b->camera_pos.x - pas;
            break;
        case 3:
            b->camera_pos.y = b->camera_pos.y + pas;
            break;
        case 2:
            b->camera_pos.y = b->camera_pos.y - pas;
            break;
    }

    
    if (b->camera_pos.x < 0) {
        b->camera_pos.x = 0;
    }
    if (b->camera_pos.x + b->camera_pos.w > 3200) {
        b->camera_pos.x = 3200 - b->camera_pos.w;
    }

  
    if (b->camera_pos.y < 0) {
        b->camera_pos.y = 0;
    }
    if (b->camera_pos.y + b->camera_pos.h > 700) {
        b->camera_pos.y =700 - b->camera_pos.h;
    }
}

void liberer_image(background b) 
{
SDL_FreeSurface(b.img) ;
}

void saveScore(ScoreInfo s, char *fileName) {
char buffer[50];
    FILE *fichier = fopen(fileName, "a");
    if (fichier == NULL) {
        printf("Impossible d'ouvrir le fichier %s.\n", fileName);
        exit(1);
    }

    
    sprintf(buffer, "%d %d %d\n", s.nomjoueur, s.score, s.temps);

    fputs(buffer, fichier);

    // Fermer le fichier
    fclose(fichier);
}



void bestScore(char *filename, ScoreInfo t[]) {
   
    FILE *fichier = fopen(filename, "r");

    
    if (fichier == NULL) {
        printf("Impossible d'ouvrir le fichier %s.\n", filename);
    }

    int i = 0;
    while (fscanf(fichier, "%d %d %d", &t[i].nomjoueur, &t[i].score, &t[i].temps) == 3) {
        i++;
    }

    fclose(fichier);

    int n = i;
    for (i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (t[i].score < t[j].score || (t[i].score == t[j].score && t[i].temps > t[j].temps)) {
                ScoreInfo tmp = t[i];
                t[i] = t[j];
                t[j] = tmp;
            }
        }
    }

    printf("Les trois meilleurs scores:\n");
    int nbMeilleursScores = 0;
    for (i = 0; i < n; i++) {
        if (nbMeilleursScores < 3) {
            printf("%d. %d: %d points en %d secondes\n", nbMeilleursScores+1, t[i].nomjoueur, t[i].score, t[i].temps);
            nbMeilleursScores++;
        } else if (t[i].score == t[i-1].score && t[i].temps == t[i-1].temps) {
            printf("%d. %d: %d points en %d secondes\n", nbMeilleursScores, t[i].nomjoueur, t[i].score, t[i].temps);
        } else {
            break;
        }
    }
}

void animer_image(background *b) {
    // Variables pour stocker les informations sur la feuille de sprite
    int largeur_sprite = 642/7;
    int hauteur_sprite = 314;
   
    b->camera_pos.w = largeur_sprite;
    b->camera_pos.h = hauteur_sprite;
if(b->s==50)
b->s=0;
b->s=b->s+1;
    // Définir le temps de rafraîchissement de l'animation
    
       
        // Afficher la prochaine image
        SDL_BlitSurface(b->img,&b->camera_pos, b->sc, &b->pos_img_ecran);

       if(b->s%10==0){
        b->camera_pos.x += largeur_sprite;
        if (b->camera_pos.x >= 642) {
            b->camera_pos.x = 0;
        

        // Rafraîchir l'écran
        SDL_Flip(b->sc);
    }
  }
}


void animer_image_deux(background *b) {
    // Variables pour stocker les informations sur la feuille de sprite
    int largeur_sprite = 750/7;
    int hauteur_sprite = 143;
   
    b->camera_pos.w = largeur_sprite;
    b->camera_pos.h = hauteur_sprite;
if(b->s==50)
b->s=0;
b->s=b->s+1;
    // Définir le temps de rafraîchissement de l'animation
    
       
        // Afficher la prochaine image
        SDL_BlitSurface(b->img,&b->camera_pos, b->sc, &b->pos_img_ecran);

       if(b->s%10==0){
        b->camera_pos.x += largeur_sprite;
        if (b->camera_pos.x >= 750) {
            b->camera_pos.x = 0;
        

        // Rafraîchir l'écran
        SDL_Flip(b->sc);
    }
  }
}





void initanimation_deux(background *b)
{
b->url="hour.png"; 
b->img=IMG_Load(b->url) ; 
if (b->img == NULL) 
{
printf("unable to load background image %s \n",SDL_GetError()) ;
 return ;  
}
b->pos_img_ecran.x=800; 
b->pos_img_ecran.y=0; 
b->camera_pos.x=0; 
b->camera_pos.y=0; 
b->camera_pos.h=SCREEN_H ; 
b->camera_pos.w=SCREEN_W ;

}





void initialiser_texte_score(texte *txte )
{ 
 TTF_Init; //initialiser SDL_ttf 
txte -> police = TTF_OpenFont("Dark-Graffiti.ttf",30) ;

txte -> color_txt.r =0 ; 
txte -> color_txt.g =0 ; 
txte -> color_txt.b = 0; 

txte -> pos_txt.x =1200; 
txte -> pos_txt.y =700;


 
}







void afficher_texte_score(SDL_Surface *screen, ScoreInfo t[], texte txte) {
    char message[100];
    int x = 700;
    int y = 200;
    int w, h;

    

    for (int i = 0; i < 3; i++) {
        snprintf(message, 100, "%d. %d: %d points en %d secondes", i+1, t[i].nomjoueur, t[i].score, t[i].temps);
        txte.txt = TTF_RenderText_Blended(txte.police, message, txte.color_txt);
        txte.pos_txt.x = x;
        txte.pos_txt.y = y;
        SDL_BlitSurface(txte.txt, NULL, screen, &txte.pos_txt);
        SDL_FreeSurface(txte.txt);
        TTF_SizeText(txte.police, message, &w, &h);
        y += h + 10;
    }

    SDL_Flip(screen);
}



   /*------------------------3 liberation du texte ------------------*/

// on utilise TTF_CloseFont pour fermer la police 
// puis TTF_Quit pour arreter le SDL_ttf
void liberer_texte_score(texte txte) 
{
//TTF_CloseFont(txte.police) ; //fermer la police
//TTF_Quit() ; // arreter la SDL_ttf 
SDL_FreeSurface(txte.txt) ;                                    
}

void initialiser_audio(Mix_Music *music)
{// initialiser les fonction audio de SDL_mixer
 if (Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS ,1024)==-1)
   {printf("%s",SDL_GetError()) ; }
//jouer le son
//pour charger la musique on utilise Mix_LoadMUS 
//pour jouer le son on utilise Mix_playMusic
//pour regler le volume en utilise Mix_VolumeMusic 
 music=Mix_LoadMUS("song.mp3"); // chargement de la musique
 Mix_PlayMusic(music,-1) ; //  jouer la musique 
 Mix_VolumeMusic(MIX_MAX_VOLUME/1) ; 
}

void liberer_musique(Mix_Music *music)
{ Mix_FreeMusic(music) ; }

//aziz


void initialiser_imageBACK(image *image)
{
image->url="k.png" ; 
image->img=IMG_Load(image->url) ; 
if (image->img == NULL) 
{
printf("unable to load background image %s \n",SDL_GetError()) ;
 return ;  
}
image->pos_img_ecran.x=0 ; 
image->pos_img_ecran.y=0 ; 

image->pos_img_affiche.x=0 ; 
image->pos_img_affiche.y=0; 

image->pos_img_affiche.h=521 ; 
image->pos_img_affiche.w=595 ; 

}

void initialiser_imageBOUTON1(image *imgbtn) 
{
//chargement de l'image
imgbtn->url="head.png" ; //pour la fonction d'initialisation de l'image du bouton on definit l'url de l'emplacement du fichier de l'image  
imgbtn->img=IMG_Load(imgbtn->url); 
if (imgbtn->img ==NULL)
   {printf("unable to load background image %s ",SDL_GetError());
   return ;}

imgbtn->pos_img_ecran .x=100; 
imgbtn->pos_img_ecran.y=50 ;
imgbtn->pos_img_ecran.w=200 ;
imgbtn->pos_img_ecran.h=200;

 
imgbtn->pos_img_affiche.x=0 ; 
imgbtn->pos_img_affiche.y=0;
imgbtn->pos_img_affiche.w=0;
imgbtn->pos_img_affiche.h=0 ; 

//on initialise la position du premier deux boutons au milieu de l'ecran su l'axe des x (a l'horizentale ) et au niveau de 1/3 de l'ecran sur l'axe y (a la verticale )
//imgbtn->pos_img_affiche.x=((SCREEN_W-imgbtn->pos_img_affiche.w)/2) ;
//imgbtn->pos_img_affiche.y=((SCREEN_H-imgbtn->pos_img_affiche.h)/3) ;
}

void initialiser_imageBOUTON2(image *imgbtn) 
{
//chargement de l'image
imgbtn->url="hurts.png" ; //pour la fonction d'initialisation de l'image du bouton on definit l'url de l'emplacement du fichier de l'image  
imgbtn->img=IMG_Load(imgbtn->url); 
if (imgbtn->img ==NULL)
   {printf("unable to load background image %s ",SDL_GetError());
   return ;}

imgbtn->pos_img_ecran .x=100; 
imgbtn->pos_img_ecran.y=50 ;
imgbtn->pos_img_ecran.w=200 ;
imgbtn->pos_img_ecran.h=200;

 
imgbtn->pos_img_affiche.x=0 ; 
imgbtn->pos_img_affiche.y=0;
imgbtn->pos_img_affiche.w=0;
imgbtn->pos_img_affiche.h=0 ; 

//on initialise la position du premier deux boutons au milieu de l'ecran su l'axe des x (a l'horizentale ) et au niveau de 1/3 de l'ecran sur l'axe y (a la verticale )
//imgbtn->pos_img_affiche.x=((SCREEN_W-imgbtn->pos_img_affiche.w)/2) ;
//imgbtn->pos_img_affiche.y=((SCREEN_H-imgbtn->pos_img_affiche.h)/3) ;
}




//l'emplacement du fichier image bouton
//pour la fonction d'initialisation de l'image bouton on definit l'url de l'emplacement du fichier de l'image 


 


       /*-------------------- 2 affichage de l'image ----------------------*/
 // la fonction SDL_BlitSurface() permet de  coller et afficher l'image sur  screen


// ----------affichage du background ------------
void afficher_imageBMP(SDL_Surface *screen , image image )
{ 
SDL_BlitSurface(image.img ,NULL , screen , &image.pos_img_ecran ) ; // la fonction SDL_BlitSurface() permet de  coller et afficher l'image du back sur  screen
}

void afficher_imageBTN1(SDL_Surface *screen , image image )
{ 
SDL_BlitSurface(image.img ,NULL   , screen ,&image.pos_img_ecran ) ; // la fonction SDL_BlitSurface() permet de  coller et afficher l'image du bonton play dans le screen
 
}

void afficher_imageBTN2(SDL_Surface *screen , image image )
{ 
SDL_BlitSurface(image.img ,NULL   , screen ,&image.pos_img_ecran ) ; // la fonction SDL_BlitSurface() permet de  coller et afficher l'image du bonton play dans le screen
 
}


   /*------------------------3 liberation image -------------------*/
// on utilise SDL_FreeSurface()
void liberer_imagee(image image) 
{
SDL_FreeSurface(image.img) ;
}


/*-------------------------------------TRAITEMENT MUSIQUE ------------------------------------*/

   /*------------------------1 initialisation de l'audio  -------------------*/

// pour initialiser l'audio en utilse la fonction de SDL_mixer : :MixOpenAudio
 
void initialiser_audioe(Mix_Music *music)
{// initialiser les fonction audio de SDL_mixer
 if (Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS ,1024)==-1)
   {printf("%s",SDL_GetError()) ; }
//jouer le son
//pour charger la musique on utilise Mix_LoadMUS 
//pour jouer le son on utilise Mix_playMusic
//pour regler le volume en utilise Mix_VolumeMusic 
 music=Mix_LoadMUS("happy.mp3"); // chargement de la musique
 Mix_PlayMusic(music,-1)  ;//  jouer la musique 
 Mix_VolumeMusic(MIX_MAX_VOLUME/3.5) ; 
}


   /*------------------------3 liberation musique -------------------*/
void liberer_musiquee(Mix_Music *music)
{ Mix_FreeMusic(music) ; }





//enigme:

void afficherEnigme(SDL_Surface* screen, enigme e ) {
   
//declarations
    SDL_Colour text_color;
    SDL_Surface* questionsurface;
    SDL_Surface* r1surface;
    SDL_Surface* r2surface;
    SDL_Surface* r3surface;

    SDL_Rect questionpos;
    SDL_Rect r1pos;
    SDL_Rect r2pos;
    SDL_Rect r3pos;

    TTF_Font* font = NULL;
    int font_loaded = 0;

    // Load the font
    while (!font_loaded) {
        font = TTF_OpenFont("MontserratAlternates-Black.otf", 30);
        if (font == NULL) {
            printf("Could not load font. Retrying in 1 second...\n");
            SDL_Delay(1000); // Wait 1 second before retrying
        } else {
            font_loaded = 1;
        }
    }
    
    // Load text surfaces
    text_color.r=255;
    text_color.g=255;
    text_color.b=255;
    questionsurface = TTF_RenderText_Blended(font, e.question, text_color);
    r1surface = TTF_RenderText_Blended(font, e.r1, text_color);
    r2surface = TTF_RenderText_Blended(font, e.r2, text_color);
    r3surface = TTF_RenderText_Blended(font, e.r3, text_color);
    
    // Set text positions
    questionpos.x=5;
    questionpos.y=10;

    r1pos.x=70;
    r1pos.y=120;

    r2pos.x=70;
    r2pos.y=150;

    r3pos.x=70;
    r3pos.y=180;
    
    // Blit text surfaces onto screen surface
    SDL_BlitSurface(questionsurface, NULL, screen, &questionpos);
    SDL_BlitSurface(r1surface, NULL, screen, &r1pos);
    SDL_BlitSurface(r2surface, NULL, screen, &r2pos);
    SDL_BlitSurface(r3surface, NULL, screen, &r3pos);
    
   
    SDL_Flip(screen);

    // Clean up
    TTF_CloseFont(font);
    SDL_FreeSurface(questionsurface);
    SDL_FreeSurface(r1surface);
    SDL_FreeSurface(r2surface);
    SDL_FreeSurface(r3surface);
}




/* // Free surfaces and font
    SDL_FreeSurface(questionsurface);
    SDL_FreeSurface(r1surface);
    SDL_FreeSurface(r2surface);
    SDL_FreeSurface(r3surface);
    TTF_CloseFont(font); */



void genererEnigme(char* filename, enigme* e) {
  FILE* fp = fopen(filename, "r");

    // Generate a random number between 1 and 3 (the number of questions in the file)
    int random_question_index = rand() % 3 + 1;

    // Select the random question from the file
    int current_question_index = 0;
    char line[500];
    while (fgets(line, sizeof(line), fp)) {
        switch (current_question_index % 5) {
            case 0:
                strcpy(e->question, line);
                break;
            case 1:
                strcpy(e->r1, line);
                break;
            case 2:
                strcpy(e->r2, line);
                break;
            case 3:
                strcpy(e->r3, line);
                break;
            case 4:
                if (current_question_index / 5 == random_question_index - 1) {
                    e->numbr = atoi(line);
                    // Found the random question, stop reading the file
                    fclose(fp);
                    return;
                }
                break;
        }
        current_question_index++;
    }

    // Don't forget to close the file
    fclose(fp);
}



void animate(enigme *e) {
    int frame = 0;
    char *image_names[3] = {"fire1.png", "fire2.png", "fire3.png"};

    // Load the images into the Enigme struct
    for (int i = 0; i < 3; i++) {
        e->images[i].url = image_names[i];
        e->images[i].img = IMG_Load(image_names[i]);
        e->images[i].pos_img_affiche.x = 500;
        e->images[i].pos_img_affiche.y = 600;
        e->images[i].pos_img_ecran.x = 356;
        e->images[i].pos_img_ecran.y = 14;
    }

    while (frame < 3) {
        // Blit the current image onto the screen
        SDL_BlitSurface(e->images[frame].img, NULL, e->screen, &e->images[frame].pos_img_ecran);
        SDL_Flip(e->screen);

        // Wait for some time
        SDL_Delay(280);

        // Remove the current image from the screen

        // Free the memory allocated for the current image
        SDL_FreeSurface(e->images[frame].img);

        // Move to the next image

        frame++;
    }
}



void save (personne p, background b, char* nomfich)
{

FILE * fp= fopen(nomfich, "w");
if (fp!= NULL){

fprintf(fp,"vie: %d\nscore: %d\npositions:\ncameraposx : %hd\ncameraposy : %hd\nposscreen.x : %hd\nposscreen.y :%hd",p.vie,p.score,b.camera_pos.x,b.camera_pos.y,p.pos_Screen.x,p.pos_Screen.y);
fclose(fp);
}else{

printf("unable to write into file");

}



}


void load(personne* p, background* b, char* nomfich) {
    FILE * fp= fopen(nomfich, "r");
    if (fp != NULL) {
        fscanf(fp, "%d\n %d\n %hd\n %hd\n %hd\n %hd",&p->vie, &p->score, &b->camera_pos.x, &b->camera_pos.y, &p->pos_Screen.x, &p->pos_Screen.y);
        fclose(fp);
    } else {
        printf("unable to read from file");
    }
}


void initialiser_imageloadsettings(image *image)
{
image->url="loadsave.png" ; 
image->img=IMG_Load(image->url) ; 
if (image->img == NULL) 
{
printf("unable to load background image %s \n",SDL_GetError()) ;
 return ;  
}
image->pos_img_ecran.x=200 ; 
image->pos_img_ecran.y=200 ; 

image->pos_img_affiche.x=0 ; 
image->pos_img_affiche.y=0; 

image->pos_img_affiche.h=0 ; 
image->pos_img_affiche.w=0 ; 

}

void afficher_imageload(SDL_Surface *screen , image image )
{ 
SDL_BlitSurface(image.img ,NULL, screen ,&image.pos_img_ecran ) ; // la 
 
}

//end of aziz




///////////////////////////////////siwar//////////////////////////////////////////


//minimap


void initmap( minimap *m)
{
	m->position_mini.x=250;
	m->position_mini.y=0;
	m->sprite=NULL;
    m->sprite=IMG_Load("minimap1.png");
}

void afficherminimap (minimap m, SDL_Surface * screen)
{
	
    SDL_BlitSurface(m.sprite, NULL, screen, &m.position_mini);
   
}
void free_minimap (minimap *m)
{
    SDL_FreeSurface(m->sprite);
}


//chrono+countdown


 
void initialiser_temps(temps *t, int duree_totale, int countdown_en_cours)
{
    t->texte = NULL;
    t->position.x = 10;
    t->position.y = 500;
    t->police = NULL;
    t->police = TTF_OpenFont("avocado.ttf", 40);
    strcpy(t->entree, "");
    t->go = 1;

    // Initialiser en mode chrono
    t->secondes_restantes = 0;
    t->countdown_en_cours = 0;

    // Si le mode countdown est activé, initialiser en mode countdown
    if (countdown_en_cours) {
        t->countdown_en_cours = 1;
        t->secondes_restantes = duree_totale;
    }

    t->duree_totale = duree_totale;
  t->t1 = SDL_GetTicks();
}



void afficher_temps(temps *t, SDL_Surface *screen)
{
    SDL_Color couleurblanche = {255, 255, 255};

 if (t->countdown_en_cours)
{
   

    // Compte à rebours
    if (t->go  && t->secondes_restantes > 0)
    {
        Uint32 t2 = SDL_GetTicks();
        Uint32 millisecondesEcoulees = t2 - t->t1;
        Uint32 secondesEcoulees = millisecondesEcoulees / 1000;

        if (t->secondes_restantes != t->duree_totale - secondesEcoulees)
        {
            t->secondes_restantes = t->duree_totale - secondesEcoulees;
            if (t->secondes_restantes == 0) {
                t->go = 0; // arrêter le chrono à 00:00
                t->countdown_en_cours = 0; // arrêter le compte à rebours
            } else {
                t->min = t->secondes_restantes / 60;
                t->sec = t->secondes_restantes % 60;
                sprintf(t->entree, "%02d:%02d", t->min, t->sec);
            }
        }
    }
}

    else
    {
        // Chronomètre
        if (t->go== 1)
        {
            Uint32 t2 = SDL_GetTicks();
            Uint32 millisecondesEcoulees = t2 - t->t1;
            Uint32 secondesEcoulees = millisecondesEcoulees / 1000;

            if (t->secondes_restantes != secondesEcoulees)
            {
                t->secondes_restantes = secondesEcoulees;
                t->min = t->secondes_restantes / 60;
                t->sec = t->secondes_restantes % 60;
                sprintf(t->entree, "%02d:%02d", t->min, t->sec);
            }
        }
    }

    // Afficher le temps restant
    t->texte = TTF_RenderText_Blended(t->police, t->entree, couleurblanche);
    SDL_BlitSurface(t->texte, NULL, screen, &t->position);
   // SDL_FreeSurface(t->texte);
}

void free_temps(temps *t)
{
    SDL_FreeSurface(t->texte);
    if (t->police != NULL) // vérifier si la police est bien chargée avant de la libérer
    {
        TTF_CloseFont(t->police);
    }
}




//animation 2


//animation demande 
 
void initialiseMinimap(minimap1 *n, int nb_frames_right, int nb_frames_left) {
    n->direction = 0;
    n->posSprite = (SDL_Rect) { 0, 0, 0, 0 };
    n->nb_frames[6] = nb_frames_right;
    n->nb_frames[4] = nb_frames_left;

    // Charger l'image du sprite
    n->sprite = IMG_Load("minimap_spritesheet.png");

    // Calculer la taille d'un frame
    int largeur_sprite = n->sprite->w;
    int hauteur_sprite = n->sprite->h;
    int NBC = (nb_frames_right > nb_frames_left) ? nb_frames_right : nb_frames_left;
    n->posSprite.w = largeur_sprite / NBC;
    n->posSprite.h = hauteur_sprite ;
}


void animerMinimap(minimap1 *n) { 
    int largeur_sprite = n->sprite->w;
    int hauteur_sprite = n->sprite->h;
    int NBC = (n->nb_frames[0] > n->nb_frames[1]) ? n->nb_frames[0] : n->nb_frames[1];

    // Changer la position du sprite
    if (n->posSprite.x == largeur_sprite - n->posSprite.w) {
        n->posSprite.x = 0;
    } else {
        n->posSprite.x += n->posSprite.w;
    }
    n->posSprite.y = n->direction * n->posSprite.h;

    // dernier frame de la direction actuelle
    int current_direction = n->direction * NBC;
    if (n->posSprite.x == 0 && n->posSprite.y == current_direction + (n->nb_frames[n->direction] - 1) * n->posSprite.h) {
        n->direction = (n->direction + 1) % 2;



    }
SDL_Delay(200);
}




void libererMinimap(minimap1 *n) {
    if (n->sprite != NULL) {
        SDL_FreeSurface(n->sprite);
        n->sprite = NULL;
    }
    n->direction = 0;
    n->posSprite = (SDL_Rect) { 0, 0, 0, 0 };
    n->nb_frames[0] = 0;
    n->nb_frames[1] = 0;
}



//animation fl minimap


//animation ajoute
void init_anim( anim *a)

{
	a->position_anim.x=900;
	a->position_anim.y=110;
	a->sprite=NULL;
    a->sprite=IMG_Load("what.png");
    
    
}

void afficher_anim(anim a, SDL_Surface *screen)
{
    static int visible = 1;  
    static int lastTime = 0; 
    
    int currentTime = SDL_GetTicks();
    
    // toggle the visibility of the image every 500 milliseconds (0.5 seconds
    if (currentTime - lastTime > 500) {
        visible = !visible;
        lastTime = currentTime;
    }
    
    if (visible) {
        SDL_BlitSurface(a.sprite, NULL, screen, &a.position_anim);
       
    }
    
   
    SDL_Delay(5);
}

void free_anim (anim *a)
{
    SDL_FreeSurface(a->sprite);
    
     
}



//collision 


SDL_Color GetPixel(SDL_Surface *Background, int x, int y)
{
        
        SDL_Color color;
        Uint32 col = 0;
        //Determine position

                char *pixelPosition = (char*)Background->pixels;
                //Offset by Y
                pixelPosition += (Background->pitch * y);
                //Offset by X
                pixelPosition += (Background->format->BytesPerPixel * x);
                //Copy pixel data
                memcpy(&col, pixelPosition, Background->format->BytesPerPixel);
                //Convert to color
                SDL_GetRGB(col, Background->format, &color.r, &color.g, &color.b);

                return (color);
}


int collisionPP( personne p, SDL_Surface * Masque)
{
    SDL_Color test ,couleurnoir= {255,0,0};

    SDL_Rect pos[8];
    pos[0].x=p.position_perso.x-100;
    pos[0].y=p.position_perso.y;
    pos[1].x=p.position_perso.x+p.position_perso.w/2-100;
    pos[1].y=p.position_perso.y;
    pos[2].x=p.position_perso.x+p.position_perso.w-100;
    pos[2].y=p.position_perso.y;
    pos[3].x=p.position_perso.x;
    pos[3].y=p.position_perso.y+p.position_perso.h/2;   
    pos[4].x=p.position_perso.x-100;
    pos[4].y=p.position_perso.y+p.position_perso.h;
    pos[5].x=p.position_perso.x+p.position_perso.w/2-100;
    pos[5].y=p.position_perso.y+p.position_perso.h;
    pos[6].x=p.position_perso.x+p.position_perso.w-100;
    pos[6].y=p.position_perso.y+p.position_perso.h;    
    pos[7].x=p.position_perso.x+p.position_perso.w-100;
    pos[7].y=p.position_perso.y+p.position_perso.h/2;


     int collision=0 , x ,y ;

     for(int i=0 ;i<8 && collision==0;i++)
     {
        x=pos[i].x;
        y=pos[i].y;
        test=GetPixel(Masque,x,y);
        if(test.r==255 && test.g==0 && test.b==0)
            collision=1;
     }
     return collision;

}
/////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////
/*-------------mouvement mini perso -----------------*/

void initminiPerso(personne *p  )  //  initialisation de la perosnnage principale
{
p->url="miniperson.png" ; 
p->sprite=IMG_Load(p->url) ; 
if (p->sprite == NULL) 
{
printf("unable to load background image %s \n",SDL_GetError()) ;
 return ;  
}
p->pos_Screen.x=500 ; 
p->pos_Screen.y=120; 
p->pos_Sprite.x=0 ; 
p->pos_Sprite.y=420; 

p->pos_Sprite.w=100; 
p->pos_Sprite.h=105 ;


if (p->direction ==1  ) //i9adam 
{p->pos_Sprite.x=0 ; 
p->pos_Sprite.y=420; 

p->pos_Sprite.w=100; 
p->pos_Sprite.h=105 ; }

else if (p->direction == 0  )  // iwa5ar 
{p->pos_Sprite.x=0 ; 
p->pos_Sprite.y=525; 


p->pos_Sprite.w=100; 
p->pos_Sprite.h=105 ; }

/*else if (p->d ==-1  )  // attack imin 
{p->pos_Sprite.x=0 ; 
p->pos_Sprite.y=0; 


p->pos_Sprite.w=260 ; 
p->pos_Sprite.h=273 ;}*/

else 
{p->pos_Screen.x=250; 
p->pos_Screen.y=135; 
p->pos_Sprite.x=0 ; 
p->pos_Sprite.y=420; 

p->pos_Sprite.w=100; 
p->pos_Sprite.h=105 ;}

p->vitesse=5;  // initialisation du vitessse a une valeur   
p->acceleration=0;   // acceleration constante 0 
 
p->up=0 ; // initialisation du champ  saut a 0 
}

void moveminiPerso (personne *p , Uint32 dt  )   
{
double dx ; 


if (p->acceleration == 0 ) 
{
  if (p->direction==1 )  
     {p->vitesse=0;// ha8oma il spritesheet il tsawer kifech yo8hrou
       if (p->pos_Sprite.x <400 ) 
         {p->pos_Sprite.x=p->pos_Sprite.x+100 ; }
      else 
          { p->pos_Sprite.x=0 ; 
            p->pos_Sprite.y=420; 
          }
         // ha8ouma i9adem bil position 
       if ( p->pos_Screen.x<=1070 ) 
                 {  p->pos_Screen.x=p->pos_Screen.x+4;      
                     p->pos_Screen.y=p->pos_Screen.y ;
                  } 
     
   
    
 
      
     } 
 else if  (p->direction==0 )  //bich yerja3  
     { 
        // ha8ouma ili i7arkou il sprite sheet ili yirja3 fiha il personnage 
      if (p->pos_Sprite.x <=400)
         {p->pos_Sprite.x=p->pos_Sprite.x+100; }
      else 
          { p->pos_Sprite.x=0; 
            p->pos_Sprite.y=525; 
          } 
       // ha8ouma iwa5ar bil position 
         if ( p->pos_Screen.x>300)  
                   p->pos_Screen.x=p->pos_Screen.x-4; 
    }
  
else if  (p->direction== 2  ) // wa9if 
{p->pos_Sprite.x=0 ; 
 p->pos_Sprite.y=420;
if (p->d == -1 ) 
{if (p->pos_Sprite.x ==100) 
         {p->pos_Sprite.x=p->pos_Sprite.x+100 ; }
      else 
          { p->pos_Sprite.x=0 ; 
            p->pos_Sprite.y=0; 
          } 
}}
else if  (p->direction== 3  )  // wa9if 
{p->pos_Sprite.x=0; 
 p->pos_Sprite.y=525;
if (p->d == -1 ) 
{if (p->pos_Sprite.x ==100 ) 
         {p->pos_Sprite.x=p->pos_Sprite.x+100 ; }
      else 
          { p->pos_Sprite.x=0 ; 
            p->pos_Sprite.y=105; 
          } 
}}
else {return ; }

}

else 
{ if (p->vitesse <5 )
   { dx = 0.5 * p->acceleration * dt * dt + p->vitesse * dt;
     if (p->direction==1 )  
     {// ha8oma il spritesheet il tsawer kifech yo8hrou
      if (p->pos_Sprite.x <400  ) 
         {p->pos_Sprite.x=p->pos_Sprite.x+100 ; }
      else 
          { p->pos_Sprite.x=100 ; 
            p->pos_Sprite.y=420; 
          }
         // ha8ouma i9adem bil position 
       if ( p->pos_Screen.x<100) 
                  {  p->pos_Screen.x+=dx;      
                     p->pos_Screen.y=p->pos_Screen.y ;
                  }   
      
     } 
 else if  (p->direction==0 )  //bich yerja3  
     {
        // ha8ouma ili i7arkou il sprite sheet ili yirja3 fiha il personnage 
      if (p->pos_Sprite.x <400)
         {p->pos_Sprite.x=p->pos_Sprite.x+100 ; }
      else 
          { p->pos_Sprite.x=100; 
            p->pos_Sprite.y=525; 
          } 
       // ha8ouma iwa5ar bil position 
         if ( p->pos_Screen.x>2141) 
                   p->pos_Screen.x-=dx; 
    }

else if  (p->direction== 2  ) // wa9if 
{p->pos_Sprite.x=0 ; 
 p->pos_Sprite.y=420;}
else if  (p->direction== 3  )  // wa9if 
{p->pos_Sprite.x=0; 
 p->pos_Sprite.y=525;}
else {return ; }

 p->vitesse = p->vitesse+ p->acceleration * dt; // mettre a jour la vitesse en fonction de l acceleration
   
 if (p->vitesse < 0)
    {
        p->vitesse = 0;
        p->acceleration = 0;
    }

     
   }

}

}













void sautminiperso( personne *p,int dt, int posinit)  // saut du personnage  ( posinit la position initiale du personnage ) saut normale du personnage 
{     
if (p->up == 1  ) 
{
  if (p->direction==1 || p->direction== 2  )  
    { 
       p->pos_Sprite.x=0 ; 
       p->pos_Sprite.y=211; 

      if (p->pos_Sprite.x <=100 ) 
         {p->pos_Sprite.x=p->pos_Sprite.x+94 ; }
      else 
          { p->pos_Sprite.x=0; 
            p->pos_Sprite.y=420; 
          }

       //bich  yitla3 il fou9 bil position 
       if ( posinit>400) 
         {p->pos_Screen.x =p->pos_Screen.x ;  
          p->pos_Screen.y=p->pos_Screen.y-5;
          }
 
      
     } 
   else if  (p->direction==0 ||p->direction== 3 )  //bich yerja3  
     { 
        p->pos_Sprite.x=0 ; 
        p->pos_Sprite.y=315; 

       if (p->pos_Sprite.x <=100 ) 
         {p->pos_Sprite.x=p->pos_Sprite.x+94 ; }
       else 
          { p->pos_Sprite.x=0; 
            p->pos_Sprite.y=525; 
          }

       //bich  yitla3 il fou9 bil position 
       if ( posinit>400) 
           {p->pos_Screen.x =p->pos_Screen.x ;  
            p->pos_Screen.y=posinit-5;}
    }


}

 
}















void drouj_mini ( personne *p, int posx_absolu, int posy_absolu) //  yitla3 il drouj 
{

if (p->up==5 || p->direction==1 || p->direction==3 )  
{ //bich  yitla3 il fou9 bil parabole  
if ( posy_absolu>0) 
    {p->pos_Screen.x =p->pos_Screen.x+17 ;  
     p->pos_Screen.y=posy_absolu-17;}
}
if (p->up==5 || p->direction==2 ||  p->direction==0 )  
{ //bich  yitla3 il fou9 bil parabole  
if ( posy_absolu>0) 
    {p->pos_Screen.x =p->pos_Screen.x-17 ;  
     p->pos_Screen.y=posy_absolu-17;}
}



}

void saut_mini_personnage ( personne *p, Uint32 dt, int posx_absolu, int posy_absolu) // saut parabolique 
{

if (p->up==3 && p->direction==1 ) 
{ //bich  yitla3 il fou9 bil parabole  
if ( posy_absolu>0 ) 
    {p->pos_Screen.x =p->pos_Screen.x+38 ;  // 9otlou yimchi distance x 100 wa yitla3 50
     p->pos_Screen.y=posy_absolu-19;}

}
if (p->up==3 && p->direction==0 && p->pos_Screen.x>0 ) 
{ //bich  yitla3 il fou9 bil parabole  
if ( posy_absolu>0) 
    {p->pos_Screen.x =p->pos_Screen.x-38 ;  // 9otlou yimchi distance x 100 wa yitla3 50
     p->pos_Screen.y=posy_absolu-19;}

}

if (p->up==3 && p->direction==2)  // saut para wa9if imin
{ //bich  yitla3 il fou9 bil parabole  
if ( posy_absolu>0 ) 
    {p->pos_Screen.x =p->pos_Screen.x+38 ;  // 9otlou yimchi distance x 100 wa yitla3 50
     p->pos_Screen.y=posy_absolu-19;}

}
if (p->up==3 && p->direction==3 && p->pos_Screen.x>0 )  // saut paraboli wa9if isar 
{ //bich  yitla3 il fou9 bil parabole  
if ( posy_absolu>0) 
    {p->pos_Screen.x =p->pos_Screen.x-38 ;  // 9otlou yimchi distance x 100 wa yitla3 50
     p->pos_Screen.y=posy_absolu-19;}

}


}






