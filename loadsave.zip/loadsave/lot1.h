#ifndef LOT1_H
#define LOT1_H



/*--------------------------------------manipuler l"image du personnage ------------------------*/

#define SCREEN_H 600
#define SCREEN_W 1200



///////////////////////////////////chaima ////////////////////////////

typedef struct 
{ // url une chaine de caractere conenant l'emplacement du fichier image
  char *url ; 

 //partie de l'image doit etre afficher 
 SDL_Rect    pos_img_affiche; // son type est SDL_Rect qui definit la position de l'image par rapport a l'ecran
 
 // position de l'image par rapport a l'ecran 
 SDL_Rect      pos_img_ecran ; // son type est SDL_Rect qui precise quelle partie de l'image doit etre afficher 
 
 SDL_Surface    *img ;   // declaration d'un pointeur de surface pour manipuler l'image

}image; 


typedef struct 
{


SDL_Rect position_perso;
 	
char *url ; // url une chaine de caractere conenant l'emplacement du fichier image

SDL_Rect  pos_Screen ;  // position de l'image par rapport de l"ecran 
SDL_Rect  pos_Sprite  ;  // positon  de l"image par rapport du sprite

SDL_Surface *sprite  ;  //declaration d un pointeur image du sprite sheet pour manipuler l image 


int direction  ,d  ;  // direction  de deplacement 


int score , vie ; 
double vitesse,  acceleration;

int up ; // stocker l etat du personnage 1 MVT saut sinon 0 

double dx ; 

}personne ; 


// initialisation
void initPerso(personne *p )  ; 	  // initialiser personnage principale 	
void movePerso (personne *p , Uint32 dt )   ; //deplacer personnage avec acceleration  !! 
void saut( personne *P,int dt, int posinit) ; // saut du personnage principale avec  posinit la position initiale du personnage saut normale du personnage 
void drouj ( personne *p, int posx_absolu, int posy_absolu) ; // yitla3 ill drouj 
void saut_personnage ( personne *P, Uint32 dt, int posx_absolu, int posy_absolu)  ; // saut parabolique du personnage 

void init(personne * p, int numperso)  ; // initialisation 2 joueur 

//affichage 
void afficherPerso(personne p, SDL_Surface * screen); // affichage du personnage principale 
 
// animation personnage 
void animerPerso (personne* p) ; 

// liberation 
void liberer_perso_image(personne p) ; 






//on a besoin de definir une structure texte :
typedef struct 
{
SDL_Surface *txt ; // un pointeur SDL_Surface pour manipuler le texte 
SDL_Rect pos_txt  ; // preciser sa position de l'image par rapport a l'ecran
SDL_Colour color_txt ; // couleur de texte en format (r,g,b) doit etre entre 0 et 255
TTF_Font *police ; // la police du texte se trouve sur un fichier de police (format.ttf)

char ch[3] ; 
}texte ; 



//definition pour la manipulation du texte
void initialiser_texte(texte *txte ,int k ,int k2 ,int *score  ) ;
void afficher_texte(SDL_Surface *screen , texte txte) ; 
void liberer_texte(texte txte) ; 




void initialiser_feu(image *imgbtn)  ;
void afficher_feu(SDL_Surface *screen , image image ) ;
void liberer_imageb(image p) ;



void initialiser_coeur(personne *p ,int i ,int *vie) ;    // initialisation image coeur 
void initialiser_lost(personne *p );  

              //------------

void initialiser_audiobrefj1(Mix_Chunk *music) ;
void initialiser_audiobrefj2(Mix_Chunk *music) ;
void initialiser_audiobrefj3(Mix_Chunk *music) ;
void liberer_musiquebrefj(Mix_Chunk *music) ;

/*-----------------------------------khalil --------------------------------------------*/

typedef struct 
{char *url ;
SDL_Surface *img; 
SDL_Surface *sc;
SDL_Rect pos_img_ecran; 
SDL_Rect camera_pos;
int s;
}background; 

typedef struct{
int nomjoueur;
int score;
int temps;
}ScoreInfo;


void initBack(background *b);
void afficherback(SDL_Surface* screen,background b);
void liberer_image(background b) ;

void scrolling(background *b,int direction,int pas);

void bestScore(char *filename, ScoreInfo t[]);
void saveScore(ScoreInfo s, char *fileName);

void initanimation(background *b);
void animer_image(background *b);

void initanimation_deux(background *b);
void animer_image_deux(background *b);

void initialiser_texte_score(texte *txte );
void bestScore(char *filename, ScoreInfo t[]);
void afficher_texte_score(SDL_Surface *screen, ScoreInfo t[], texte txte);
void liberer_texte_score(texte txte);

void initialiser_audio(Mix_Music *music) ; 
void liberer_musique(Mix_Music *music) ;
	//AZIZ
typedef struct {
    FILE* f;
    char question[400];
    char r1[50];
    char r2[50];
    char r3[50];
    int numbr;
    char x[50];
    image images[3];
SDL_Surface *screen;
} enigme;


void afficherEnigme(SDL_Surface *screen, enigme e);

// definition des fenetre des fonction 

//definition pour la manipulation de l'image 
void initialiser_imageBACK(image *image) ; 
void initialiser_imageBOUTON1(image *image) ; 
void initialiser_imageBOUTON2(image *image) ; 

void afficher_imageBTN1(SDL_Surface *screen , image image ) ;
void afficher_imageBTN2(SDL_Surface *screen , image image) ;

void afficher_imageBMP(SDL_Surface *screen , image image) ; 
void genererEnigme(char* filename, enigme* e);

void animate(enigme *e);

void liberer_imagee(image image) ; 


//definition pour la manipulation de l'audio 
void initialiser_audioe(Mix_Music *music) ; 
void liberer_musiquee(Mix_Music *music) ;




void initialiser_imageloadsettings(image *image);
void afficher_imageload(SDL_Surface *screen , image image );

void save (personne p, background b, char* nomfich);

void load(personne* p, background* b, char* nomfich);
//END OF AZIZ	







////siwar//////////////////



typedef struct 
{ SDL_Surface *joueur;

	SDL_Rect position_mini;
	SDL_Surface *sprite;
}minimap;


typedef struct  {
    
    SDL_Surface *sprite;
   
    SDL_Surface *surface;
SDL_Rect pos;
   
    int direction;
    int num;
  

    SDL_Rect posScreen;
    SDL_Rect posSprite;
   
    int nb_frames[4];         
} minimap1;






typedef struct temps {
    char entree[32];
    int countdown_en_cours; 
    int go; 
    int secondes_restantes;
    int duree_totale; 
    int min; 
    int sec; 
    Uint32 t1; 
    SDL_Surface *texte;
    TTF_Font *police;
    SDL_Rect position;
} temps;

typedef struct 
{
	SDL_Rect position_anim;
	SDL_Surface *sprite;
}anim;



////////////////////////////////////////////////////siwar////////////////////////////////////////
//lminimap 


void initmap( minimap *m);
void afficherminimap (minimap m, SDL_Surface * screen);
void free_minimap (minimap *m);


//temps siwar 
void initialiser_temps(temps *t, int duree_totale, int countdown);
void afficher_temps(temps *t, SDL_Surface *screen);
void free_temps(temps *t);

//mta3 !
void init_anim( anim *a);
void afficher_anim (anim a, SDL_Surface * screen);
void free_anim (anim *a);


//animationsiwar hourglass
void initialiseMinimap(minimap1 *n, int nb_frames_right, int nb_frames_left) ;
void animerMinimap(minimap1 *n);
void libererMinimap(minimap1 *n);

//collision 

SDL_Color GetPixel(SDL_Surface *Background, int x, int y);
int collisionPP( personne p, SDL_Surface * Masque);


void initminiPerso(personne *p  ) ; 
void moveminiPerso (personne *p , Uint32 dt )   ; 


void sautminiperso( personne *p,int dt, int posinit) ;  
void drouj_mini ( personne *p, int posx_absolu, int posy_absolu)  ; 
void saut_mini_personnage( personne *p, Uint32 dt, int posx_absolu, int posy_absolu) ; 



























#endif 
