#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h> 
#include <SDL/SDL_image.h>

#include "background.h" 


void initBack(background *b)
{
b->url="enemy.png"; 
b->img=IMG_Load(b->url) ; 
if (b->img == NULL) 
{
printf("unable to load background image %s \n",SDL_GetError()) ;
 return ;  
}
b->pos_img_ecran.x=0; 
b->pos_img_ecran.y=0; 
b->camera_pos.x=0; 
b->camera_pos.y=0; 
b->camera_pos.h=SCREEN_H ; 
b->camera_pos.w=SCREEN_W ;

}


void initanimation(background *b)
{
b->url="fire.png"; 
b->img=IMG_Load(b->url) ; 
if (b->img == NULL) 
{
printf("unable to load background image %s \n",SDL_GetError()) ;
 return ;  
}
b->pos_img_ecran.x=50; 
b->pos_img_ecran.y=0; 
b->camera_pos.x=0; 
b->camera_pos.y=0; 
b->camera_pos.h=SCREEN_H ; 
b->camera_pos.w=SCREEN_W ;

}




void afficherback(SDL_Surface *screen,background b )
{ 
SDL_BlitSurface(b.img ,&b.camera_pos , screen , &b.pos_img_ecran ) ; 
}

void scrolling(background *b, int direction) {
    switch (direction) {
        case 0:
            b->camera_pos.x += 6;
            break;
        case 1:
            b->camera_pos.x = b->camera_pos.x - 6;
            break;
        case 2:
            b->camera_pos.y = b->camera_pos.y + 6;
            break;
        case 3:
            b->camera_pos.y = b->camera_pos.y - 6;
            break;
    }

    
    if (b->camera_pos.x < 0) {
        b->camera_pos.x = 0;
    }
    if (b->camera_pos.x + b->camera_pos.w > 4000) {
        b->camera_pos.x = 4000 - b->camera_pos.w;
    }

  
    if (b->camera_pos.y < 0) {
        b->camera_pos.y = 0;
    }
    if (b->camera_pos.y + b->camera_pos.h > 1020) {
        b->camera_pos.y =1020 - b->camera_pos.h;
    }
}
void liberer_image(background b) 
{
SDL_FreeSurface(b.img) ;
}


/*void liberer_main(personne p) 
{
SDL_FreeSurface(p.sprite) ;
}*/

void saveScore(ScoreInfo s, char *fileName) {
char buffer[50];
    FILE *fichier = fopen(fileName, "a");
    if (fichier == NULL) {
        printf("Impossible d'ouvrir le fichier %s.\n", fileName);
        exit(1);
    }

    
    sprintf(buffer, "%s %d %d\n", s.nomjoueur, s.score, s.temps);

    fputs(buffer, fichier);

    // Fermer le fichier
    fclose(fichier);
}








void bestScore(char *filename, ScoreInfo t[]) {
    
    FILE *fichier = fopen(filename, "r");

    
    if (fichier == NULL) {
        printf("Impossible d'ouvrir le fichier %s.\n", filename);
    }

    int i = 0;
    while (fscanf(fichier, "%s %d %d", t[i].nomjoueur, &t[i].score, &t[i].temps) == 3) {
        i++;
    }

    fclose(fichier);

    int n = i;
    for (i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (t[i].score < t[j].score || (t[i].score == t[j].score && t[i].temps > t[j].temps)) {
                ScoreInfo tmp = t[i];
                t[i] = t[j];
                t[j] = tmp;
            }
        }
    }

    printf("Les trois meilleurs scores:\n");
    int nbMeilleursScores = 0;
    for (i = 0; i < n; i++) {
        if (nbMeilleursScores < 3) {
            printf("%d. %s: %d points en %d secondes\n", nbMeilleursScores+1, t[i].nomjoueur, t[i].score, t[i].temps);
            nbMeilleursScores++;
        } else if (t[i].score == t[i-1].score && t[i].temps == t[i-1].temps) {
            printf("%d. %s: %d points en %d secondes\n", nbMeilleursScores, t[i].nomjoueur, t[i].score, t[i].temps);
        } else {
            break;
        }
    }
}

/*void animer_image(background *b, SDL_Surface *Screen) {
    // Variables pour stocker les informations sur la feuille de sprite
    int largeur_sprite = (916/ 7);
    int hauteur_sprite = 314;
    
    b->camera_pos.w = largeur_sprite;
    b->camera_pos.h = hauteur_sprite;
    

  
    
        // Afficher la prochaine image
        SDL_BlitSurface(b->img,&b->camera_pos, Screen, &b->pos_img_ecran);

        // Mettre à jour la position du sprite
       b->camera_pos.x+= largeur_sprite;
        if (b->camera_pos.x >= 916) {
            b->camera_pos.x = 0;
        }

        // Attendre un court instant pour ralentir l'animation
        SDL_Delay(10);

        // Rafraîchir l'écran
        SDL_Flip(Screen);
    
}
*/
void animer_image(background *b) {
    // Variables pour stocker les informations sur la feuille de sprite
    int largeur_sprite = 642/7;
    int hauteur_sprite = 314;
   
    b->camera_pos.w = largeur_sprite;
    b->camera_pos.h = hauteur_sprite;
if(b->s==50)
b->s=0;
b->s=b->s+1;
    // Définir le temps de rafraîchissement de l'animation
    
       
        // Afficher la prochaine image
        SDL_BlitSurface(b->img,&b->camera_pos, b->sc, &b->pos_img_ecran);

       if(b->s%10==0){
        b->camera_pos.x += largeur_sprite;
        if (b->camera_pos.x >= 642) {
            b->camera_pos.x = 0;
        

        // Rafraîchir l'écran
        SDL_Flip(b->sc);
    }
  }
}


void initPerso(personne *p  )  //  initialisation de la perosnnage principale
{
p->url="main.png" ; 
p->sprite=IMG_Load(p->url) ; 
if (p->sprite == NULL) 
{
printf("unable to load background image %s \n",SDL_GetError()) ;
 return ;  
}
p->pos_Screen.x=0 ; 
p->pos_Screen.y=0; 
p->pos_Sprite.x=0 ; 
p->pos_Sprite.y=524; 

p->pos_Sprite.w=213; 
p->pos_Sprite.h=262 ;


if (p->direction ==1  ) //i9adam 
{p->pos_Sprite.x=0 ; 
p->pos_Sprite.y=524; 

p->pos_Sprite.w=213; 
p->pos_Sprite.h=262 ; }

else  // iwa5ar 
{p->pos_Sprite.x=623 ; 
p->pos_Sprite.y=0; 


p->pos_Sprite.w=213; 
p->pos_Sprite.h=262 ; }

p->vitesse=5;  // initialisation du vitessse a une valeur   
p->acceleration=0;   // acceleration constante 0 
 
p->up=0 ; // initialisation du champ a 0 
}

void movePerso(personne *p , Uint32 dt)   
{
double dx ; 

/*-------------------------------------------------*/
 if (p->acceleration == 0 ) 
{
  if (p->direction==1 )  
     {p->vitesse=0;// ha8oma il spritesheet il tsawer kifech yo8hrou
       if (p->pos_Sprite.x <=522  ) 
         {p->pos_Sprite.x=p->pos_Sprite.x+213 ; }
      else 
          { p->pos_Sprite.x=213 ; 
            p->pos_Sprite.y=524; 
          }
         // ha8ouma i9adem bil position 
       if ( p->pos_Screen.x<623) 
                  {  p->pos_Screen.x=p->pos_Screen.x+1 ;      
                     p->pos_Screen.y=p->pos_Screen.y ;
                  }   
      
     } 
 else if  (p->direction==0 )  //bich yerja3  
     {
        // ha8ouma ili i7arkou il sprite sheet ili yirja3 fiha il personnage 
      if (p->pos_Sprite.x >= 0)
         {p->pos_Sprite.x=p->pos_Sprite.x-213 ; }
      else 
          { p->pos_Sprite.x=637; 
            p->pos_Sprite.y=0; 
          } 
       // ha8ouma iwa5ar bil position 
         if ( p->pos_Screen.x>0)  
                   p->pos_Screen.x=p->pos_Screen.x-1; 
    }
else if  (p->direction== 2  ) // wa9if 
{p->pos_Sprite.x=0 ; 
 p->pos_Sprite.y=524;}
else if  (p->direction== 3  )  // wa9if 
{p->pos_Sprite.x=637; 
 p->pos_Sprite.y=0;}
else {return ; }

}

else 
{ if (p->vitesse <5 )
   { dx = 0.5 * p->acceleration * dt * dt + p->vitesse * dt;
     if (p->direction==1 )  
     {// ha8oma il spritesheet il tsawer kifech yo8hrou
       if (p->pos_Sprite.x <=522  ) 
         {p->pos_Sprite.x=p->pos_Sprite.x+213 ; }
      else 
          { p->pos_Sprite.x=213 ; 
            p->pos_Sprite.y=524; 
          }
         // ha8ouma i9adem bil position 
       if ( p->pos_Screen.x<623) 
                  {  p->pos_Screen.x+=dx;      
                     p->pos_Screen.y=p->pos_Screen.y ;
                  }   
      
     } 
 else if  (p->direction==0 )  //bich yerja3  
     {
        // ha8ouma ili i7arkou il sprite sheet ili yirja3 fiha il personnage 
      if (p->pos_Sprite.x >= 0)
         {p->pos_Sprite.x=p->pos_Sprite.x-213 ; }
      else 
          { p->pos_Sprite.x=637; 
            p->pos_Sprite.y=0; 
          } 
       // ha8ouma iwa5ar bil position 
         if ( p->pos_Screen.x>0) 
                   p->pos_Screen.x-=dx; 
    }
else if  (p->direction== 2  ) // wa9if 
{p->pos_Sprite.x=0 ; 
 p->pos_Sprite.y=524;}
else if  (p->direction== 3  )  // wa9if 
{p->pos_Sprite.x=637; 
 p->pos_Sprite.y=0;}
else {return ; }

 p->vitesse = p->vitesse+ p->acceleration * dt; // mettre a jour la vitesse en fonction de l acceleration
   
 if (p->vitesse < 0)
    {
        p->vitesse = 0;
        p->acceleration = 0;
    }


   }

 /*else 
   { p->acceleration =0 ;   }*/




}
}



void afficherPerso(personne p, SDL_Surface * screen)	// affichage du personnage principale  
{
SDL_BlitSurface(p. sprite ,&p.pos_Sprite   , screen , &p.pos_Screen ) ; 

}



void initialiser_audio(Mix_Music *music)
{// initialiser les fonction audio de SDL_mixer
 if (Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS ,1024)==-1)
   {printf("%s",SDL_GetError()) ; }
//jouer le son
//pour charger la musique on utilise Mix_LoadMUS 
//pour jouer le son on utilise Mix_playMusic
//pour regler le volume en utilise Mix_VolumeMusic 
 music=Mix_LoadMUS("song.mp3"); // chargement de la musique
 Mix_PlayMusic(music,-1) ; //  jouer la musique 
 Mix_VolumeMusic(MIX_MAX_VOLUME/1) ; 
}

void liberer_musique(Mix_Music *music)
{ Mix_FreeMusic(music) ; }

