#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
/*--------ETAPE 0 DECLARATION DU BIBLIOTHEQUE SDL ---------------*/
#include <SDL/SDL_ttf.h>    // pour manipuler des texte 
#include <SDL/SDL_image.h>  // pour manipuler des image 
#include <SDL/SDL_mixer.h>  // pour manipuler des audio 

 
#include "background.h"  
 

int main()
{
//initialisation texte ,video et son!!!!
TTF_Init();
SDL_Init(SDL_INIT_VIDEO);
/* ---------ETAPE 1 DECLARATION DES VARIABLE----------- */
SDL_Surface *screen ;  // screen variable pointeur sur surface de l'arriere plan
background B,A ;
int direction=-1;
int boucle=1;
SDL_Event event;
int con=0;
Mix_Music  *music ; 

personne IMAGE_main ,IMAGE ;
 const Uint8* keystates = SDL_GetKeyState(NULL);

int test = 0 ; 
int indicate = 0 ;  // variable pour indiquer que le bouton still lef or write  
Uint32 dt, t_prev ;  // pur calculer le  temp

// initialisation de l sdl
if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER)==-1)
{printf("could not initialize SDL : %s .\n " ,SDL_GetError()) ;
 return -1 ; }

// initialisation de la fenetre 
 screen= SDL_SetVideoMode(SCREEN_W ,SCREEN_H , 32 , SDL_SWSURFACE | SDL_RESIZABLE) ; 
A.s=0;
A.sc=screen;

initBack(&B) ;
initPerso(&IMAGE_main);
initanimation(&A);
initialiser_audio(music) ; 

while(boucle) 
{	
afficherback(screen,B) ; 
afficherPerso(IMAGE_main ,screen) ;




 
   while(SDL_PollEvent(&event)) 
   {  

         switch(event.type){

 
        case SDL_KEYDOWN :


                switch(event.key.keysym.sym){
                    case SDLK_RIGHT:
                        direction = 0;
                        con=1;
                        break;
                    case SDLK_LEFT:
                        direction = 1;
                        con=1;
                        break;
                    case SDLK_UP:
                        direction = 2;
                        con=1;
                        break;
                    case SDLK_DOWN:
                        direction = 3;
                        con=1;
                        break;
		     case  SDL_QUIT: 
            boucle=0 ; 
         break ; 
}


           if (event.key.keysym.sym==SDLK_ESCAPE) 
               boucle=0 ; 

if (event.key.keysym.sym == SDLK_RIGHT) // i9adem il 9odem 
              {  IMAGE_main.direction = 1 ; IMAGE_main.acceleration=0;
                 indicate = 1 ;
               }
             
          if (event.key.keysym.sym==SDLK_LEFT)  // yarja3  bil twali 
                {IMAGE_main.direction = 0;  IMAGE_main.acceleration=0;
                 indicate = 1 ; 
                }

          if (event.key.keysym.sym == SDLK_f) // touch acceleration  
              { IMAGE_main.acceleration+=0.005;}

           if (event.key.keysym.sym == SDLK_g) // touch deceleration 
              {IMAGE_main.acceleration-=0.11;}
         
         if (event.key.keysym.sym==SDLK_DOWN)  // yahbat 
               {  if ( IMAGE_main.pos_Screen.y<=500) 
                    {IMAGE_main.pos_Screen.y=IMAGE_main.pos_Screen.y+20 ;  }
               }

           /*if (event.key.keysym.sym==SDLK_f)   // sautt 
                {IMAGE_main.up=1;   
                saut( &IMAGE_main,dt,IMAGE_main.pos_Screen.y) ; }*/   


          break ;  
		
	case SDL_KEYUP: // wa9tlili il bouton yirja3 normale houwa bich ya9if

 switch(event.key.keysym.sym){
                    case SDLK_RIGHT:
                        if (direction == 0) {
                            con=0;
                        }
                        break;
                    case SDLK_LEFT:
                        if (direction == 1) {
                           con=0;
                        }
                        break;
                    case SDLK_UP:
                        if (direction == 2) {
                            con=0;
                        }
                        break;
                    case SDLK_DOWN:
                        if (direction == 3) {
                            con=0;
                        }
                        break;
}
 
          if (event.key.keysym.sym == SDLK_RIGHT) {
           indicate = 0 ; IMAGE_main.direction = 2 ;
          }
           if (event.key.keysym.sym == SDLK_LEFT) {
           indicate = 0 ;IMAGE_main.direction = 3 ;
          }
           
         if (event.key.keysym.sym == SDLK_f) // touch acceleration  
              {IMAGE_main.acceleration-=0.005;}
          if (event.key.keysym.sym == SDLK_g) // touch deceleration 
              {IMAGE_main.acceleration+=0.11;}
          break;

	       


 	/*break;
          if (event.key.keysym.sym==SDLK_RIGHT) 
              { direction=0;
	      scrolling(&B,direction);
			boucle=0;}
		break;
 	 else  if (event.key.keysym.sym==SDLK_LEFT) 
              { direction=1;
	       scrolling(&B,direction);}
		break;
           else if (event.key.keysym.sym==SDLK_UP) 
              { direction=2;
	       scrolling(&B,direction);}
		break;	
           else if (event.key.keysym.sym==SDLK_DOWN) 
              { direction=3;
	       scrolling(&B,direction);}
		break;

        case  SDL_QUIT: 
            boucle=0 ; 
         break ; */
       }

 }
if (con==1) 
{scrolling(&B,direction); }

if (indicate ) 
{movePerso(&IMAGE_main ,dt) ; }
else if  (indicate == 0 && IMAGE_main.direction == 2 )//yerje3 wa9if normale ba3d man7arkouh right
{movePerso(&IMAGE_main ,dt) ;}
else if(indicate == 0 && IMAGE_main.direction == 3 )//yerja3 wa9if normale ba3d man7arkouh left 
{movePerso(&IMAGE_main ,dt) ;  }

dt=SDL_GetTicks()-t_prev; // ala fin de la boucle du jeu 
animer_image(&A);


SDL_Flip(screen) ;
}
liberer_image(B) ; 
liberer_image(A) ; 
liberer_main(IMAGE_main);
liberer_musique(music) ; 


SDL_Quit() ;  



return 0 ; 
}









