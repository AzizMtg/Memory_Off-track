#ifndef TEXTE_H
#define TEXTE_H
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>   
#define SCREEN_H 1000
#define SCREEN_W 2000
#include <SDL/SDL_mixer.h> 
#include <SDL/SDL_image.h>

typedef struct 
{char *url ;
SDL_Surface *img; 
SDL_Surface *sc;
SDL_Rect pos_img_ecran; 
SDL_Rect camera_pos;
int s;
}background; 

typedef struct{
char nomjoueur[30];
int score;
int temps;
}ScoreInfo;

typedef struct 
{
char *url ; // url une chaine de caractere conenant l'emplacement du fichier image

SDL_Rect  pos_Screen ;  // position de l'image par rapport de l"ecran 
SDL_Rect  pos_Sprite  ;  // positon  de l"image par rapport du sprite

SDL_Surface *sprite  ;  //declaration d un pointeur image du sprite sheet pour manipuler l image 

int direction   ;  // direction  de deplacement 
int up ; // stocker l etat du personnage 1 MVT saut sinon 0 

int score , vie ; 
double vitesse,  acceleration;

}personne ; 


// initialisation
/*void initPerso(personne *p )  ; 	  // initialiser personnage principale 	
void movePerso (personne *p , Uint32 dt )   ; //deplacer personnage avec 
void afficherPerso(personne p, SDL_Surface * screen);
void liberer_main(personne p);*/

/*void initBack(background *b);
void afficherback(SDL_Surface* screen,background b);
void scrolling(background *b,int direction);
void liberer_image(background b) ;
void bestScore(char *filename, ScoreInfo t[]);
void saveScore(ScoreInfo s, char *fileName);

void initanimation(background *b);
void animer_image(background *b);*/

void initialiser_audio(Mix_Music *music) ; 
void liberer_musique(Mix_Music *music) ;


#endif 
